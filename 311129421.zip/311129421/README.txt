Bautista Cazares David ---- 314153537
Álvares de la Rosa Carlos Alexis ---- 314355456
Zaldivar Rico William Oceloth ---- 311129421
David Iván Morales Campos ---- 313327726


El reporte se encuentra en la carpeta doc.

El diagrama se encuentra en la carpeta doc.